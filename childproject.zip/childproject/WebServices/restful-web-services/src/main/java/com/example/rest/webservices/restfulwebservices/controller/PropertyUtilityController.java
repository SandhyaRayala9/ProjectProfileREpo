package com.example.rest.webservices.restfulwebservices.controller;

import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import utility.property.PropertyHandler;

@RestController
public class PropertyUtilityController {
	/*
	 * @Autowired private PropertyHandler util;
	 */

	@RequestMapping("/utilityHandler")
	public void fetchProperty() throws Exception 
	{
		Properties prop=PropertyHandler.fetchProperties();
		String name= prop.getProperty("name");
		String place= prop.getProperty("place");
		System.out.println("name ="+name);
		System.out.println("place ="+ place);

	}
}
