package utility.property;
import java.util.Properties;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
@RunWith(SpringRunner.class)
public class PropertyHandlerTest {

	@Test
	public void testFetchProperties() throws Exception {
		Properties prop=PropertyHandler.fetchProperties();
		String user= prop.getProperty("db.user");
		String password= prop.getProperty("db.password");
		String url= prop.getProperty("db.url");
		System.out.println("user ="+user);
		System.out.println("password ="+ password);
		System.out.println("url ="+ url);
	}

}
